import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import { useThemeStore } from './store/theme-store';
import { Navbar } from './components/layout/navbar';
import { Hero } from './components/home/hero';
import { FeaturedCourses } from './components/home/featured-courses';
import { LoginPage } from './pages/login';
import { SignupPage } from './pages/signup';
import { CoursesPage } from './pages/courses';
import { CourseDetailsPage } from './pages/course-details';

function HomePage() {
  return (
    <main>
      <Hero />
      <FeaturedCourses />
    </main>
  );
}

function App() {
  const { theme } = useThemeStore();

  return (
    <Router>
      <div className={theme}>
        <div className="min-h-screen bg-background text-foreground">
          <Navbar />
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/login" element={<LoginPage />} />
            <Route path="/signup" element={<SignupPage />} />
            <Route path="/courses" element={<CoursesPage />} />
            <Route path="/courses/:id" element={<CourseDetailsPage />} />
          </Routes>
        </div>
      </div>
    </Router>
  );
}

export default App;