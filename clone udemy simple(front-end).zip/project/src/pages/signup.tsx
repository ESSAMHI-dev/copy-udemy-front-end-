import { AuthForm } from '../components/auth/auth-form';

export function SignupPage() {
  return <AuthForm type="signup" />;
}