import { ArrowLeft, Clock, GraduationCap, Star } from 'lucide-react';
import { Link, useParams } from 'react-router-dom';
import { Button } from '../components/ui/button';
import { courses } from '../data/courses';

export function CourseDetailsPage() {
  const { id } = useParams<{ id: string }>();
  const course = courses.find((c) => c.id === Number(id));

  if (!course) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <h1>Course not found</h1>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <Link
        to="/courses"
        className="inline-flex items-center text-primary hover:underline mb-8"
      >
        <ArrowLeft className="h-4 w-4 mr-2" />
        Back to Courses
      </Link>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <img
            src={course.image}
            alt={course.title}
            className="w-full h-[400px] object-cover rounded-lg mb-8"
          />
          <h1 className="text-4xl font-bold mb-4">{course.title}</h1>
          <p className="text-muted-foreground mb-8">{course.description}</p>

          <div className="grid grid-cols-3 gap-4 mb-8">
            <div className="flex items-center gap-2">
              <Clock className="h-5 w-5 text-primary" />
              <span>{course.duration}</span>
            </div>
            <div className="flex items-center gap-2">
              <GraduationCap className="h-5 w-5 text-primary" />
              <span>{course.level}</span>
            </div>
            <div className="flex items-center gap-2">
              <Star className="h-5 w-5 text-yellow-500" />
              <span>{course.rating}</span>
            </div>
          </div>

          <h2 className="text-2xl font-bold mb-4">What you'll learn</h2>
          <ul className="list-disc list-inside space-y-2 mb-8">
            {course.topics?.map((topic) => (
              <li key={topic}>{topic}</li>
            ))}
          </ul>
        </div>

        <div className="lg:col-span-1">
          <div className="bg-card rounded-lg p-6 shadow-lg sticky top-8">
            <div className="text-3xl font-bold mb-4">${course.price}</div>
            <Button className="w-full mb-4">Enroll Now</Button>
            <div className="text-sm text-muted-foreground">
              <p className="mb-2">This course includes:</p>
              <ul className="space-y-2">
                <li>• Full lifetime access</li>
                <li>• Access on mobile and desktop</li>
                <li>• Certificate of completion</li>
                <li>• 30-day money-back guarantee</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}