import { AuthForm } from '../components/auth/auth-form';

export function LoginPage() {
  return <AuthForm type="login" />;
}