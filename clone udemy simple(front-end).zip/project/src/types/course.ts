export interface Course {
  id: number;
  title: string;
  instructor: string;
  price: number;
  image: string;
  rating: number;
  description?: string;
  duration?: string;
  level?: string;
  topics?: string[];
}