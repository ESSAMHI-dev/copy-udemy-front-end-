import { BookOpen, Moon, Sun } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useThemeStore } from '../../store/theme-store';
import { Button } from '../ui/button';

export function Navbar() {
  const { theme, toggleTheme } = useThemeStore();

  return (
    <nav className="border-b">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16 items-center">
          <Link to="/" className="flex items-center space-x-2">
            <BookOpen className="h-8 w-8 text-primary" />
            <span className="text-xl font-bold">LearnHub</span>
          </Link>

          <div className="flex items-center space-x-4">
            <Link to="/courses">
              <Button variant="ghost">Courses</Button>
            </Link>
            <Link to="/login">
              <Button variant="ghost">Login</Button>
            </Link>
            <Button variant="default">Sign Up</Button>
            <Button variant="ghost" size="icon" onClick={toggleTheme}>
              {theme === 'light' ? (
                <Moon className="h-5 w-5" />
              ) : (
                <Sun className="h-5 w-5" />
              )}
            </Button>
          </div>
        </div>
      </div>
    </nav>
  );
}