import { ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Button } from '../ui/button';

const FEATURED_COURSES = [
  {
    id: 1,
    title: 'Complete Web Development Bootcamp',
    instructor: 'Sarah Johnson',
    price: 89.99,
    image: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085',
    rating: 4.8,
  },
  {
    id: 2,
    title: 'Advanced Machine Learning',
    instructor: 'Dr. Michael Chen',
    price: 129.99,
    image: 'https://images.unsplash.com/photo-1555949963-aa79dcee981c',
    rating: 4.9,
  },
  {
    id: 3,
    title: 'Digital Marketing Masterclass',
    instructor: 'Emily Parker',
    price: 69.99,
    image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f',
    rating: 4.7,
  },
];

export function FeaturedCourses() {
  return (
    <section className="py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-3xl font-bold">Featured Courses</h2>
          <Link to="/courses">
            <Button variant="ghost" className="flex items-center gap-2">
              View All <ArrowRight className="h-4 w-4" />
            </Button>
          </Link>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {FEATURED_COURSES.map((course) => (
            <div
              key={course.id}
              className="bg-card rounded-lg overflow-hidden shadow-lg"
            >
              <img
                src={course.image}
                alt={course.title}
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-2">{course.title}</h3>
                <p className="text-muted-foreground mb-4">
                  by {course.instructor}
                </p>
                <div className="flex justify-between items-center">
                  <span className="text-lg font-bold">${course.price}</span>
                  <span className="text-sm text-yellow-500">
                    ★ {course.rating}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}